from src.libro import Libro

def test_crear_libro():
    libro = Libro("Clean Code", "Robert Martin", 2008)

    assert libro.titulo == "Clean Code"
    assert libro.autor == "Robert Martin"
    assert libro.anio == 2008
    
def test_antiguedad_libro():
    libro = Libro("Libro X", "Autor", 2020)
    assert libro.antiguedad(2025) == 5

import pytest

def test_libro_sin_titulo():
    with pytest.raises(ValueError):
        Libro("", "Autor", 2020)