from src.database import SessionLocal, engine, Base
from src.models import LibroDB

def test_guardar_libro_db():
    # Crear tablas antes del test
    Base.metadata.create_all(bind=engine)

    session = SessionLocal()

    libro = LibroDB(titulo="DB Test", autor="Autor", anio=2024)
    session.add(libro)
    session.commit()

    resultado = session.query(LibroDB).filter_by(titulo="DB Test").first()

    assert resultado is not None

    session.close()