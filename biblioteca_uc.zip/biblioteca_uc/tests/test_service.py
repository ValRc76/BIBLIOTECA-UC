from src.service import BibliotecaService

def test_crear_libro_service():
    service = BibliotecaService()
    libro = service.crear_libro("Clean Code", "Robert Martin", 2008)
    assert libro.titulo == "Clean Code"


def test_listar_libros():
    service = BibliotecaService()
    libros = service.listar_libros()
    assert isinstance(libros, list)


def test_buscar_libro():
    service = BibliotecaService()
    service.crear_libro("Python", "Autor", 2022)
    libro = service.buscar_libro("Python")
    assert libro is not None


def test_eliminar_libro():
    service = BibliotecaService()
    service.crear_libro("Eliminar", "Autor", 2020)
    service.eliminar_libro("Eliminar")
    libro = service.buscar_libro("Eliminar")
    assert libro is None