from src.database import engine, Base

Base.metadata.create_all(bind=engine)

print("Base de datos creada")