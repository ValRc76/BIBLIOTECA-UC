from sqlalchemy import Column, Integer, String
from src.database import Base

class LibroDB(Base):
    __tablename__ = "libros"

    id = Column(Integer, primary_key=True)
    titulo = Column(String)
    autor = Column(String)
    anio = Column(Integer)