class Libro:
    def __init__(self, titulo, autor, anio):
        if not titulo:
            raise ValueError("El título no puede estar vacío")

        self.titulo = titulo
        self.autor = autor
        self.anio = anio

    def antiguedad(self, anio_actual):
        if anio_actual < self.anio:
            return 0
        return anio_actual - self.anio