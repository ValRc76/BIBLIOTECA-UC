from src.database import SessionLocal
from src.models import LibroDB

class BibliotecaService:

    def crear_libro(self, titulo, autor, anio):
        session = SessionLocal()

        libro = LibroDB(titulo=titulo, autor=autor, anio=anio)
        session.add(libro)
        session.commit()

        session.refresh(libro)
        session.close()
        return libro

    def listar_libros(self):
        session = SessionLocal()
        libros = session.query(LibroDB).all()
        session.close()
        return libros

    def buscar_libro(self, titulo):
        session = SessionLocal()
        libro = session.query(LibroDB).filter_by(titulo=titulo).first()
        session.close()
        return libro

    def eliminar_libro(self, titulo):
        session = SessionLocal()
        libro = session.query(LibroDB).filter_by(titulo=titulo).first()

        if libro:
            session.delete(libro)
            session.commit()

        session.close()