from flask import Flask, render_template, request, redirect

app = Flask(__name__)

# Lista temporal de libros
libros = []

# Página principal
@app.route('/')
def home():
    return render_template('index.html', libros=libros)

# Agregar libro
@app.route('/agregar', methods=['POST'])
def agregar_libro():
    titulo = request.form['titulo']
    autor = request.form['autor']

    nuevo_libro = {
        'titulo': titulo,
        'autor': autor
    }

    libros.append(nuevo_libro)

    return redirect('/')

# Eliminar libro
@app.route('/eliminar/<int:id>')
def eliminar_libro(id):
    if id < len(libros):
        libros.pop(id)

    return redirect('/')


if __name__ == '__main__':
    app.run(debug=True)